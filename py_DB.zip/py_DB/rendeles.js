function sendPost(){
    const data = JSON.stringify({
        name: document.getElementById("name").value,
        tel: document.getElementById("tel").value,
        address:document.getElementById("address").value
      });
      
      navigator.sendBeacon('http://127.0.0.1:5000/savedetails/', data);
      console.log(data);
    }