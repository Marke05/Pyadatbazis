import sqlite3

con = sqlite3.connect("rendeles.db")
print("Rendelesek adatbazisa sikeres")

con.execute(
    "create table Rendeles (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, tel TEXT NOT NULL, address TEXT NOT NULL)")

print("Rendelesek adatbazisa sikeres")

con.close()