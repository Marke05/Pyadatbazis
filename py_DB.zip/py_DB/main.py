from flask import *
import json
import sqlite3
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route("/view")
def view():
    con = sqlite3.connect("rendeles.db")
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("select * from Rendeles")
    rows = cur.fetchall()
    return json.dumps([dict(ix) for ix in rows])

@app.route("/savedetails/", methods=["POST"])
def saveDetails():
    msg = "msg"
    try:
        data = request.get_json(force=True)
        print(data)
        name = data["name"]
        tel = data["tel"]
        address = data["address"]
        with sqlite3.connect("rendeles.db") as con:
            cur = con.cursor()
            cur.execute("INSERT into Rendeles (name, tel, address) values (?,?,?)", (name, tel, address))
            con.commit()
            msg = "Rendeles sikeres"
    except:
        con.rollback()
        msg = "Rendeles sikertelen"
    finally:
        return name
        con.close()

@app.route("/deleterecord/", methods=["POST"])
def deleterecord():
    data = request.get_json(force=True)
    id = str(data["id"])
    print(id)
    with sqlite3.connect("rendeles.db") as con:
        try:
            cur = con.cursor()
            cur.execute("delete from Rendeles where id = ?", id)
            msg = "Rendeles torolve"
        except:
            msg = "Nem lehet torolni"

@app.route("/updatedetails/", methods=["POST"])
def updaterecord():
    try:
        data = request.get_json(force=True)
        print(data)
        id = data["id"]
        name = data["name"]
        tel = data["tel"]
        address = data["address"]

        with sqlite3.connect("rendeles.db") as con:
            cur = con.cursor()
            cur.execute("UPDATE Rendeles SET name=?, tel=?, address=? WHERE id=?", (name, tel, address, id))
            con.commit()
            msg = "Rendeles megvaltoztatasa"
    except:
        con.rollback()
        msg = "Rendelest nem lehet megvaltoztatni"
    finally:
        return msg
        con.close()

if __name__ == "__main__":
    app.run(debug=True)
